self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fbff1c532dfff5532a6e9d30bfc2012b",
    "url": "./index.html"
  },
  {
    "revision": "434dc87702bc114e2f11",
    "url": "./static/css/2.4e89ce74.chunk.css"
  },
  {
    "revision": "5aa75adc5a63b0376398",
    "url": "./static/css/main.439b4a20.chunk.css"
  },
  {
    "revision": "434dc87702bc114e2f11",
    "url": "./static/js/2.eb771a05.chunk.js"
  },
  {
    "revision": "5aa75adc5a63b0376398",
    "url": "./static/js/main.35af5bf2.chunk.js"
  },
  {
    "revision": "5992a459bcb371c76583",
    "url": "./static/js/runtime-main.22dfcdb3.js"
  },
  {
    "revision": "2d0714948c153c999d1fb1a82d95033c",
    "url": "./static/media/Goshan.2d071494.jpg"
  }
]);